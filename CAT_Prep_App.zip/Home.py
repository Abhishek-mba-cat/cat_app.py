
import streamlit as st

st.set_page_config(page_title="CAT Prep App", layout="wide")

st.title("📘 CAT Preparation App")
st.subheader("Track, Practice, and Level Up")

st.markdown("""
Welcome to your CAT exam companion app. Select from the sidebar to:
- 📅 Track daily preparation
- 🧠 Practice topic-wise MCQs
- 🧪 Attempt full mock tests
- 📊 Analyze your progress
""")

st.info("Use the sidebar to navigate through different sections.")
